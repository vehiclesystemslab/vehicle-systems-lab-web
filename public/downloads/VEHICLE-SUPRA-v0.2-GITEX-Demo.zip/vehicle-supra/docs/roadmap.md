# Roadmap

## Current phase: v0.1 alpha research prototype

Implemented:

- Structured node model.
- Weighted network model.
- Internal and external tension metrics.
- Projection-governed recovery step.
- A0-A6 classification.
- Twin-node recovery simulation.
- Enterprise network example.
- Initial unit tests.

## Next phase: v0.2 research validation

Planned:

- Expanded tests for recovery convergence.
- Benchmark stress scenarios.
- API reference.
- Cleaner example scenarios.
- Reproducible notebooks.
- Improved logging and metrics export.

## Future phase: v0.3 demonstration layer

Planned:

- Dashboard visualization.
- Multi-agent demo integration.
- Real-time regime monitoring.
- Scenario library for public demonstrations.
- Website-ready diagrams and documentation.

## Long-term direction

VEHICLE-SUPRA aims to become a research-grade architecture for coherence-governed autonomous agent networks. Production claims will require formal testing, benchmarking, safety analysis, and deployment-specific validation.
